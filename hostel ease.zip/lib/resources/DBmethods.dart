// ignore_for_file: non_constant_identifier_names

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:uuid/uuid.dart';

class DBmethods {
  Future<String> addHostel({
    required String hostelName,
    required String numberOfFloors,
    required String hostelId,
  }) async {
    try {
      String hId = const Uuid().v4();
      FirebaseFirestore.instance.collection('hostels').doc(hId).set({
        'name': hostelName,
        'numberOfFloors': numberOfFloors,
        'hostelId': hostelId,
        'hId': hId,
        'student count': 0,
        'warden count': 0,
      });
    } catch (e) {
      return e.toString();
    }
    return 'Hostel Added';
  }

  Future<String> createStudent(
      {required String studentName,
      required String studentEmail,
      required String studentRoom,
      required String studentDepartment,
      required String password,
      required String hId}) async {
    try {
      UserCredential cred = await FirebaseAuth.instance
          .createUserWithEmailAndPassword(
              email: studentEmail, password: password);
      String uid = cred.user!.uid;

      FirebaseFirestore.instance
          .collection('hostels')
          .doc(hId)
          .collection('students')
          .doc(uid)
          .set({
        'name': studentName,
        'email': studentEmail,
        'room': studentRoom,
        'department': studentDepartment,
        'hid': hId,
      });
      FirebaseFirestore.instance.collection('hostels').doc(hId).update({
        'student count': FieldValue.increment(1),
      });
    } catch (e) {
      return e.toString();
    }
    return 'Student Added';
  }

  Future<String> createWarden(
      {required String WardensName,
      required String WardensEmail,
      required String age,
      required String password,
      required String hId}) async {
    try {
      UserCredential cred = await FirebaseAuth.instance
          .createUserWithEmailAndPassword(
              email: WardensEmail, password: password);
      String uid = cred.user!.uid;

      FirebaseFirestore.instance
          .collection('hostels')
          .doc(hId)
          .collection('wardens')
          .doc(uid)
          .set({
        'name': WardensName,
        'email': WardensEmail,
        'age': age,
        'hid': hId,
      });
      FirebaseFirestore.instance.collection('hostels').doc(hId).update({
        'warden count': FieldValue.increment(1),
      });
    } catch (e) {
      return e.toString();
    }
    return 'Warden Added';
  }
}
