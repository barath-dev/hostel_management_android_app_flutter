import 'package:flutter/material.dart';

class Addfloor extends StatelessWidget {
  const Addfloor({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
        child: Center(
      child: Text('Add Floor'),
    ));
  }
}
