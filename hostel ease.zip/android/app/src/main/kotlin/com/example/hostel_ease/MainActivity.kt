package com.example.hostel_ease

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
